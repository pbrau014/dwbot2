# The Admiralty — A History of the Republic at Sea

The Admiralty begins as a small division of friends and grows into a fifty-member naval community. Its history is a story of trust, competition, growing responsibility and the decision to place shared rules above personal authority.

## The years that shaped the fleet

- **The first division:** Six friends gather for casual divisions and random battles. What begins as companionship becomes a durable community built around shared play and mutual learning.
- **2025 — Growth and training:** The roster grows toward thirty active members. Training, mentoring, reserve planning and review begin to replace word-of-mouth coordination.
- **2025 — Harbor Night:** A late roster substitution before a decisive battle is not adequately explained. The voice-channel dispute that follows reveals the need for clear notice, an opportunity for the affected player to respond and impartial review. The tactical decision itself remains separate from the failure to explain it.
- **May 2026 — The founding watch:** Aiden “Rook” Mercer and Elena “Valkyrie” Rossi receive the transitional mandates of Commander-in-Chief and Vice Commander. Their task is to lead the growing clan while its permanent institutions take shape.
- **May–July 2026 — Clan Battles Season 1:** During the founding watch, the Tier VIII, 7v7 fleet records an 18–6 campaign, finishes second in North America and reaches the final, where it loses 2–3 to Vanguard. The campaign’s opening and closing dates are remembered; the exact day of the May founding ballot is not.
- **Autumn 2026 — The first full constitutional election:** The charter’s permanent elected offices are filled. The Senate’s inaugural bridge terms, the House leadership and the temporary first-election review safeguards turn the constitutional design into a working government.
- **The next watch:** New officeholders inherit public duties, records and unfinished work. Earlier service remains part of the republic’s history; succession does not erase the people who came before.

## Offices passed between watches

Lucas “Soundings” Chen becomes the inaugural Speaker after the first Representatives take their seats. In a later House term, Emma “Signal” Wilson serves as Speaker. Naomi Pike is the founding Chief of Staff; Liam “Navigator” Reyes later succeeds her after leaving his Senate seat to accept the appointment. The office continues, but the individuals and their periods of service remain distinct.

Shared callsigns do not make shared identities. Elena “Valkyrie” Rossi and Mira “Valkyrie” Solano are different people; Emma “Signal” Wilson and Tessa “Signal” Park are different people; Sophia “Sparrow” Chen and Kira “Sparrow” Dalca are different people; Marcus “Sonar” Hale and Caleb “Sonar” Wright are different people; Talia “Tideglass” Byrne and Nia “Tideglass” Byrne are different people. Each has an individual history and place in the fleet.

## A government built around fifty members

The republic is founded on fifty unique members, counted once by their primary service assignment: twenty-five in General Membership, sixteen across the operational arms and nine in constitutional-primary assignments. The operational arms are Fleet Command, with eight members, and the Service Corps, with eight. The constitutional assignments are two Executive, four Legislative and three Judicial. Public offices are additional duties; they do not create extra members or change a member’s primary place in the roster.

The Constitution protects the rights and responsibilities of the whole clan. The Executive administers it and coordinates the portfolios. The Senate and House make and review policy. The independent Judicial Panel guards due process. Fleet Command prepares the competitive fleet and directs tactical operations; the Service Corps sustains the community and its services. General Membership remains the civic foundation of the republic.

Calendar seasons and Clan Battles seasons are separate clocks. The Commander-in-Chief, Vice Commander and six Representatives are elected at the start of each calendar season. The four Senate seats begin with an inaugural all-seat election; a public lot establishes two staggered cohorts, and thereafter two Senators are elected each season so that each Senator faces re-election every other season. Three Justices serve two calendar seasons, with a midterm retention vote after the first. The Fleet Admiral and Service Corps Director are elected for each Clan Battles season, preferably before it begins or together midseason when a pre-season ballot is impracticable. The presiding officers of the Senate, House and Judicial Panel are chosen internally by their respective members.

All fifty enrolled members, including Cadets, may qualify to vote. Eligibility requires enthusiastic, diligent and appropriate participation in at least one Clan Battles season under the same published standard. The secret Discord ballot separates voter eligibility from ballot choice; public totals and a documented audit protect confidence without exposing an individual’s vote.

## The tournament beyond the constitution

The Admiralty also hosts the YOLO tournament under a separate event mandate. The constitutional government remains responsible for the rights and internal affairs of the clan; the tournament authority publishes and administers event rules, formats, schedules, results and appeals. A member may be both organizer and competitor, but must not decide a matter that directly affects their own match. Inside a battle, ships cooperate as a team; tournament standings ordinarily recognize individual performance unless the published event rules say otherwise.

The competition may unfold through a Pilot YOLO, a recurring Road to the Grand YOLO season, Special YOLO events and a culminating championship. Each event announces its selected format and scoring before registration closes. A possible format is not a permanent rule until the host publishes it for that event.

## The six connected histories

### The Admiralty — A Republic at Sea

The people, crises, institutions and successive watches behind the naval republic. Its central question is how a close-knit group can grow without losing fairness, trust or a human sense of belonging.

### There Is No Team, It Is a YOLO! — The Human Chronicle

The tournament’s origins, competitors, experiments and changing formats. Temporary battle teams cooperate at sea while the competition ordinarily follows individual standings.

### The Battle as a Living System

Fleet doctrine as a shared language for information, pressure and choice: preparation, spotting, crossfires, objective control, adaptation and learning after the battle.

### The Decisions Behind the Tournament

The sequence connecting event authority, scope, participants, battle configuration, scoring, advancement, stewardship and review.

### The Rules as a Promise to the Player

The standing framework, event notice, battle rules, submission record, impartial review and final result that allow changing fields to compete fairly.

### The Quiet Work of a Fair Tournament

The people and procedures between the battles: invitations, notices, logistics, participant care, evidence, review, publication and learning between events.

## The watch continues

The republic’s strength is not measured only by victories. It is measured by whether a member can understand a decision, whether a losing candidate can remain part of the community, whether a commander can act decisively within clear limits and whether the next watch can inherit the work without inheriting personal claims to power. The sea changes; the obligation to one another remains.
